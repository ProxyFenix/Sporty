package com.example.sportyandroidstudio.model;

public class FicherosTry {
	
	
	public boolean test(String line) {
		String[] partes = line.split(";");
		try {
			Float.parseFloat(partes[1]);
		} catch (Exception e) {
			return false;
		}
		return (partes.length == 2);
	}

}
