package com.example.sportyandroidstudio.model;

import java.util.ArrayList;

public class ExerciseTipe {
	
	//estado
	
	//Lista de ejercicios disponibles
	protected ArrayList<Exercise> listaEjercicios;
	
	

	//comportamiento
	
	
	//Pillamos el array de ejercicios
	public ExerciseTipe() {
		listaEjercicios = new ArrayList();
	}
	
	//Anadimos uno nuevecito
	public void addEjercicio(Exercise newEj) {
		listaEjercicios.add(newEj);
	}

	
	//Pillamos por indice
	public Exercise getEjercicioByIndex(int indice) {
		return listaEjercicios.get(indice);
	}
	
	//Que dice cada ejercicio?
	public Exercise getEjercicioByDescripcion(String descripcion) {
		Exercise exerc = null;

		int i = 0;
		
		
		while (exerc==null && i<listaEjercicios.size()) {
		    if (listaEjercicios.get(i).getDescripcion() == descripcion) {
				exerc = listaEjercicios.get(i);
		    } else
		    	i++;
		}
		
		
		return exerc;
		
	}
	
}
