package com.example.sportyandroidstudio.presenter;

import com.example.sportyandroidstudio.model.Exercise;
import com.example.sportyandroidstudio.model.ExerciseTipe;
import com.example.sportyandroidstudio.model.FicherosTry;
import com.example.sportyandroidstudio.view.ExerciseView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class ExercisePresenterImpl implements ExercisePresenter {
    //estado
    protected ExerciseTipe coleccionEj;
    private static final String NOMBRE_FICHERO = "data.txt";

    private ExerciseView mView;
    public ExercisePresenterImpl(ExerciseView excerciseView){
        mView = excerciseView;
    }

    //init
    public void iniciaDatos() throws FileNotFoundException {

        //Cargamos datos del fichero
        cargarFichero();

        //Introducimos los datos
        /*for (int i = 0; i < coleccionEj.tamaño(); i++) {
            cbEjercicios.addItem(coleccionEj.getEjercicioByIndex(i).getDescripcion());
        }*/

    }


    //Calculadora time
    public String calculaKCal(float minutos, float kilos, String descr) {
        return coleccionEj.getEjercicioByDescripcion(descr).calcularKCal(minutos, kilos);
    }


    //Cargamos los datos del fichero
    public void cargarFichero() throws FileNotFoundException {
        File miFichero = new File(NOMBRE_FICHERO);
        FileWriter erroresDatos;

        Scanner scan = new Scanner(miFichero);

        Exercise newEjer;
        String nextLinea;
        FicherosTry comprobador = new FicherosTry();
        String errores = "";
        int numLinea = 1;

        while (scan.hasNextLine()) {

            nextLinea = scan.nextLine();
            if (comprobador.test(nextLinea)) {
                newEjer = new Exercise(nextLinea);
                coleccionEj.addEjercicio(newEjer);
            } else {
                //Cuantas veces revinta?
                errores += "Error en la l�nea: " + String.valueOf(numLinea) + ". Datos: " + nextLinea + "\n";
            }
            numLinea++;
        }

        scan.close();


    }

}




