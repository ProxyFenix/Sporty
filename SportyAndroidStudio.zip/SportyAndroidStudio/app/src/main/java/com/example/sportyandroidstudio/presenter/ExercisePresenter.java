package com.example.sportyandroidstudio.presenter;

import java.io.FileNotFoundException;

public interface ExercisePresenter {


    //init
    void iniciaDatos() throws FileNotFoundException;


    //Calculadora time
    String calculaKCal(float kilos, float minutos, String descripcion);


    //Cargamos los datos del fichero
    void cargarFichero() throws FileNotFoundException;


}
