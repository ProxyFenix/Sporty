package com.example.sportyandroidstudio.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.sportyandroidstudio.R;
import com.example.sportyandroidstudio.presenter.ExercisePresenter;
import com.example.sportyandroidstudio.presenter.ExercisePresenterImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class ExerciseActivity extends AppCompatActivity implements ExerciseView {
    private final String DATOS = "datos.txt";
    private Spinner  spinner;
    private Button button;
    private EditText peso,tiempo;
    private TextView res;
    private ExercisePresenter mPresenter = new ExercisePresenterImpl(this);
    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            button=(Button)findViewById(R.id.boton);
            peso=(EditText)findViewById(R.id.peso);
            tiempo=(EditText)findViewById(R.id.tiempo);
            res=(TextView)findViewById(R.id.resultado);



            spinner = (Spinner) findViewById(R.id.combo);
/*            String []opciones={};
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, opciones);
            spinner.setAdapter(adapter);*/
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    float pesoF = Float.parseFloat(peso.getText().toString());
                    float tiempoF = Float.parseFloat(tiempo.getText().toString());

                    mPresenter.calculaKCal(pesoF, tiempoF,"");

                }
            });
        }

    @Override
    public void mostrarResultado(float kcal) {
        res.setText(String.valueOf(kcal));
    }
}


