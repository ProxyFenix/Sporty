package com.example.sportyandroidstudio.model;

public class Exercise {
	//estado
	
	protected String descripcion;
	protected float met;
	
	
	//comportamientos
	
	//Constructor
	public Exercise(String serie) {
		String[] partes;
		partes = serie.split(";");
		descripcion = partes[0];
		met = Float.parseFloat(partes[1]);
	}
	
	
	//Calcular KCal
	public String calcularKCal(float minutos, float kilos) {
		return String.valueOf(minutos*kilos*met/60);
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	

}
