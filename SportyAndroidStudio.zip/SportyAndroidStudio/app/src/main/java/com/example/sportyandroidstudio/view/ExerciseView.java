package com.example.sportyandroidstudio.view;

public interface ExerciseView {
    void mostrarResultado(float kcal);
}
